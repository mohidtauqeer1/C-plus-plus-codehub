#include<iostream>
using namespace std;
int main()
{
    char key='y';
    while(key!='n'){
    cout<<"i am happy"<<endl;
    cout<<"enter your choice";
    cin>>key;
    }
    return 0;
}