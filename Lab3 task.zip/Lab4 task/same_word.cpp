 #include<iostream>
 using namespace std;
 int main()
 {
  string w1,w2;
  cout << "enter first world" << endl;
  cin>>w1;
  cout << "enter a second word" << endl;
  cin>>w2;
  if(w1==w2)
  cout << "yes is the words " <<w1<<","<<w2<<" are same"<< endl;
  else
  cout << "yes is the words " <<w1<<","<<w2<<" are not same"<< endl;
 return 0;
}