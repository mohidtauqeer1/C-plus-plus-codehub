 #include<iostream>
 using namespace std;
 int main()
 {
  int cost;
 cout << "enter cost of dress"<< endl;
 cin >> cost;
if(cost<1500)
 cout << " buy the dress";
 if(cost>1500)
 cout << " dont buy the dress";
 return 0;
}