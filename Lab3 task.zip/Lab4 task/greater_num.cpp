 #include<iostream>
 using namespace std;
 int main()
 {
  int n1,n2;
  cout << "enter a first number" << endl;
  cin>>n1;
  cout << "enter a second number" << endl;
  cin>>n2;
  if(n1>n2)
  cout << "number " <<n1<<" is greater number"<< endl;
  else
   cout << "number "<<n2 <<" is a greater number";
 return 0;
}