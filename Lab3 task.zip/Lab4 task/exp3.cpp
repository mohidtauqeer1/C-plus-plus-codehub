 #include<iostream>
 using namespace std;
 int main()
 {
  string name;
 cout << "enter your name"<< endl;
 cin >> name;
if(name=="ali")
 cout << "congratulations " <<name<< endl;
 return 0;
}