 #include<iostream>
 using namespace std;
 int main()
 {
 int cost;
 cout << "enter cost of the dress" << endl;
 cin >> cost;
 if(cost<1500)
 cout << "buy the dress" << endl;
 return 0;
}