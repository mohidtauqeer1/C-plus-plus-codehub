 #include<iostream>
 using namespace std;
 int main()
 {
  char going;
 cout << "are your friends going"<< endl;
 cin >> going;
if(going=='y')
 cout << " you are going";
 else
 cout << " you are not going";
 return 0;
}