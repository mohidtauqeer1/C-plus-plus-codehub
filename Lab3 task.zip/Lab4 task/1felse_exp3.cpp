 #include<iostream>
 using namespace std;
 int main()
 {
  string name;
 cout << "enter your name"<< endl;
 cin >> name;
if(name=="ali")
 cout << " congratulations"<<name;
 else
 cout << " try again "<<name;
 return 0;
}